package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Msupplier;
import model.MjenisIkan;
import model.Mstok;
import model.Mkaryawan;
import view.VHomeKasir;
import view.VHomeManager;
import view.VHomePgudang;
import view.VLogin;
import view.VMKelolaSupplier;
import view.VPKelolaJenisIkan;
import view.VPKelolaStock;

public class CPHomePgudang {

    String[] user;
    VHomePgudang viewHomePgudang;

    public CPHomePgudang(VHomePgudang viewhomepgudang, String[] User) {
        this.user = User;
        this.viewHomePgudang = viewhomepgudang;
        this.viewHomePgudang.setVisible(true);
        this.viewHomePgudang.setID(User[0]);
        this.viewHomePgudang.setNama(User[1]);

        this.viewHomePgudang.KelolaJenisIkanClick(new KelolaJenisIkanListener());
        this.viewHomePgudang.KelolaSupplierClick(new KelolaSupplierListener());
        this.viewHomePgudang.logoutPClick(new LoginListener());
        this.viewHomePgudang.KelolaStockClick(new KelolaStockListener());
//        this.viewHomeKasir.LihatStockKClick(new LihatStokListener());
//        this.viewHomeKasir.ModeKasir(new ModeKasirListener());
    }

    private class KelolaStockListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomePgudang.dispose();
                new CPKelolaStok(new VPKelolaStock(), new Mstok(), user);
            } catch (SQLException ex) {
                Logger.getLogger(CPHomePgudang.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class LoginListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomePgudang.dispose();
                new CLogin(new VLogin(),new Mkaryawan() );
            } catch (SQLException ex) {
                Logger.getLogger(CPHomePgudang.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class KelolaJenisIkanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomePgudang.dispose();
                new CPKelolaJenisIkan(new MjenisIkan(), new VPKelolaJenisIkan(), user);
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class KelolaSupplierListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomePgudang.dispose();
                new CMKelolaSupplier(new VMKelolaSupplier(), new Msupplier(), new VHomeManager(), "pgudang" , user);
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
