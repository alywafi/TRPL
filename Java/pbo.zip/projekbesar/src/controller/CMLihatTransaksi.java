package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Mtransaksi;
import view.VHomeManager;
import view.VMLihatTransaksi;

public class CMLihatTransaksi {

    VMLihatTransaksi view;
    Mtransaksi model;

    public CMLihatTransaksi(VMLihatTransaksi view, Mtransaksi model ) throws SQLException {
        this.view = view;
        this.model = model;
        this.view.setVisible(true);
        this.view.setTableModel(this.model.getData());

        this.view.BackLihatTransaksi(new BackListener());
    }

    private class BackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.dispose();
            new CMHomeManager(new VHomeManager());

        }

    }
}
