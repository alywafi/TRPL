package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import model.Mkaryawan;
import model.Mstok;
import model.Msupplier;
import model.Mtransaksi;
import view.VHomeKasir;
import view.VHomeManager;
import view.VHomePgudang;
import view.VLogin;
import view.VMKelolaKaryawan;
import view.VMKelolaSupplier;
import view.VMKelolaUser;
import view.VMLihatKualitas;
import view.VMLihatStok;
import view.VMLihatTransaksi;

public class CMHomeManager {

    String[] user = new String[2];
    VHomeManager viewHomeManager;

    public CMHomeManager(VHomeManager viewhomemanager) {
        this.viewHomeManager = viewhomemanager;
        this.viewHomeManager.setVisible(true);

        this.viewHomeManager.KelolaUserClick(new KelolaUserListener());
        this.viewHomeManager.LogoutMClick(new LogoutListener());
        this.viewHomeManager.KelolaKaryawanClick(new KelolaKaryawanListener());
        this.viewHomeManager.KelolaSupplierClick(new KelolaSupplierListener());
        this.viewHomeManager.LihatKualitasClick(new LihatKualitasListener());
        this.viewHomeManager.LihatStockMClick(new LihatStokListener());
        this.viewHomeManager.LihatTransaksiClick(new LihatTransaksiListener());
    }

    private class LihatTransaksiListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                new CMLihatTransaksi(new VMLihatTransaksi(), new Mtransaksi() );
                viewHomeManager.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class LihatStokListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                new CMLihatStok(new VMLihatStok(), new Mstok() , "manager", user);
                viewHomeManager.dispose();

            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class LihatKualitasListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                new CMLihatKualitas(new VMLihatKualitas(), new Msupplier() );
                viewHomeManager.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    private class LogoutListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomeManager.dispose();
                new CLogin(new VLogin(), new Mkaryawan()) ;
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class KelolaKaryawanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                new CMKelolaKaryawan(new VMKelolaKaryawan(), new Mkaryawan(), new VHomeManager());
                viewHomeManager.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class KelolaSupplierListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String[] User = new String[2];
                User[0] = "";
                User[1] = "Wafi";
                new CMKelolaSupplier(new VMKelolaSupplier(), new Msupplier(), new VHomeManager(), "manager", User);
                viewHomeManager.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class KelolaUserListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                new CMKelolaUser(new VMKelolaUser(), new Mkaryawan());
                viewHomeManager.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
