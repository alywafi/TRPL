package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Mkaryawan;
import view.VHomeManager;
import view.VMKelolaUser;

public class CMKelolaUser {

    VMKelolaUser view;
    Mkaryawan model ;

    public CMKelolaUser(VMKelolaUser view, Mkaryawan model) throws SQLException {
        this.view = view;
        this.model = model;
        this.view.setTableModel(this.model.getDataUser());
        this.view.setVisible(true);
        this.view.setSaveEnable(false);

        this.view.UpdateClick(new UpdateListener());
        this.view.BackKelolaUser(new BackListener());
        this.view.SaveClick(new SimpanListener());

    }

    private class SimpanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
               
                if (model.updateDataUser(view.getData())) { // Jika query update pada model berhasil
                    view.showMessagePane("Data Berhasil Di Simpan");
                    view.setTableModel(model.getDataUser()); //mengatur ulang isi tabel
                    view.setFieldId(""); // menggunakan method setFieldID yg sudah dibuat di view (lihat view)
                    view.setFieldUserName(""); // menggunakan method setFieldNameStatus yg sudah dibuat di view (lihat view)
                    view.setFieldPassword(""); // menggunakan method setFieldNameStatus yg sudah dibuat di view (lihat view)

                    view.setFieldIdEditable(true); // mengembalikan agar fieldID bisa di edit kembali
                    view.setUpdateEnable(true);
                } else {
                    view.showMessagePane("Data Gagal Di Simpan");
                }

                // mengkosongkan fieldID dan namaStatus pada view
            } catch (SQLException ex) {
                view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class BackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CMHomeManager(new VHomeManager());
            view.dispose();
        }

    }

    private class UpdateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (view.getSelectedRow() == -1) {
                view.showMessagePane("Pilih Dulu Cuy");
            } else {
                try {
                    String[] data = model.getDataUserWithID(view.getIdUser());
                    view.setUpdateEnable(false);
                    view.setFieldIdEditable(false);
                    view.setSaveEnable(true);

                    view.setFieldId(data[0]);
                    view.setFieldUserName(data[1]);
                    view.setFieldPassword(data[2]);
                } catch (SQLException ex) {
                    view.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

}
