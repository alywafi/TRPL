package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Mstok;
import view.VHomePgudang;
import view.VMKelolaSupplier;
import view.VPKelolaStock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USER
 */
public class CPKelolaStok {

    String[] user;

    VPKelolaStock viewKelolaStock;
    Mstok modelKelolaStock;

    public CPKelolaStok(VPKelolaStock viewkelolastok, Mstok modelkelolastok, String[] User) throws SQLException {
        this.user = User;
        this.viewKelolaStock = viewkelolastok;
        this.modelKelolaStock = modelkelolastok;

        this.viewKelolaStock.setId(User[0]);
        this.viewKelolaStock.setNama(User[1]);
        this.viewKelolaStock.setKaryawanID(User[0]);
        this.viewKelolaStock.setStokID(modelkelolastok.GetId());

        this.viewKelolaStock.setVisible(true);
        this.viewKelolaStock.setTableModelJenisIkan(this.modelKelolaStock.getDataJenisIkan());
        this.viewKelolaStock.setDefaultTableModelStok();

        this.viewKelolaStock.setSaveEnable(false);
        this.viewKelolaStock.setInsertToTableEnable(false);
        this.viewKelolaStock.setFieldIdEditable(false);

        this.viewKelolaStock.SaveStokClick(new SaveStokListener());
        this.viewKelolaStock.BackKelolaStock(new BackListener());
        this.viewKelolaStock.ResetStokClick(new ResetStokListener());
        this.viewKelolaStock.InsertIkanToTableClick(new InsertIkanToTableListener());
        this.viewKelolaStock.InsertIkanToJTClick(new InsertIkanToJTListener());

    }

    private class ResetStokListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            viewKelolaStock.setReset();

        }
    }

    private class InsertIkanToTableListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewKelolaStock.getStatusJTQuantity().isEmpty()) {
                viewKelolaStock.showMessagePane("isi dulu jumlah pembeliannya cuy");
            } else {

                viewKelolaStock.addRowTableModelStok(viewKelolaStock.getDataJenisIkanFromJT());
                viewKelolaStock.setResetInserttoTableStok();
                viewKelolaStock.setSaveEnable(true);
            }
        }
    }

    private class InsertIkanToJTListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewKelolaStock.getSelectedRow() == -1) {
                viewKelolaStock.showMessagePane("Pilih Dulu Cuy");
            } else {
                try {
                    String[] data = modelKelolaStock.getDataWithID(viewKelolaStock.getIdUser());
                    viewKelolaStock.setInsertToTableEnable(true);
                    viewKelolaStock.SetToJTJenisIkan(data);

                } catch (SQLException ex) {
                    viewKelolaStock.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }

        }
    }

    private class BackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CPHomePgudang(new VHomePgudang(), user);
            viewKelolaStock.dispose();
        }

    }

    private class SaveStokListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (!viewKelolaStock.getKualitasEmpty()) {

                if (!viewKelolaStock.getSupplierEmpty()) {

                    try {
                        if (modelKelolaStock.insertData(viewKelolaStock.getDataForDBStok())) { // Jika query update pada model berhasil
                        } else {
                            viewKelolaStock.showMessagePane("Data Gagal Di Simpan di tabel stok");
                        }

                    } catch (SQLException ex) {
                        viewKelolaStock.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                    }

                    try {
                        if (modelKelolaStock.insertDataToQuality(viewKelolaStock.getKualitas())) {
                        } else {
                            viewKelolaStock.showMessagePane("Kualitas gagal disimpan");
                        }
                    } catch (SQLException ex) {
                        viewKelolaStock.showMessagePane("Eror !, Tidak Dapat Menjalankan Query Kualitas");
                    }

                    String da[][] = viewKelolaStock.getDataStokTable();
                    for (int i = 0; i < da.length; i++) {
                        String DataInput[] = new String[3];
                        String d[] = new String[2];

                        for (int j = 0; j < 2; j++) {
                            d[j] = da[i][j];
                            DataInput[j + 1] = da[i][j + 1];
                        }

                        try {
                            DataInput[0] = modelKelolaStock.getIDWithData(d);
                            if (modelKelolaStock.insertDataToDetailed(viewKelolaStock.getStokID(), DataInput)) { // Jika query update pada model berhasil
                            } else {
                                viewKelolaStock.showMessagePane("Data Gagal Di Simpan wkwkwk");
                            }

                        } catch (SQLException ex) {
                            viewKelolaStock.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                        }

                    }
                    viewKelolaStock.showMessagePane("Data Berhasil Disimpan");
                    try {
                        viewKelolaStock.setTableModelJenisIkan(modelKelolaStock.getDataJenisIkan());
                    } catch (SQLException ex) {
                        Logger.getLogger(CPKelolaStok.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    viewKelolaStock.setReset();
                } else {
                    viewKelolaStock.showMessagePane("Suppliernya Isi DUlu Bos");

                }
            } else {
                viewKelolaStock.showMessagePane("Kualitasnya Isi DUlu Bos");

            }
        }
    }
}
