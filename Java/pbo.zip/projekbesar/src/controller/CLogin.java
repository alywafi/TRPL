package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Mkaryawan;
import view.VHomeKasir;
import view.VHomeManager;
import view.VHomePgudang;
import view.VLogin;
import view.VMKelolaSupplier;
import view.VMKelolaUser;

public class CLogin {

    VLogin viewL;
    Mkaryawan modelL ; 

    public CLogin(VLogin view, Mkaryawan model) {
        this.viewL = view;
        this.modelL = model;

        this.viewL.setVisible(true);
        this.viewL.loginClick(new LoginListener());

    }

    public CLogin() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private class LoginListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewL.getUsername().isEmpty()) {
                viewL.showMessagePane("Usernamenya diisi bro");
            } else if (viewL.getPassword().isEmpty()) {
                viewL.showMessagePane("passwordnya diisi cuy");
            } else {
                try {
                    String ILogin[] = viewL.getDataLogin();
                    String DLogin[][] = modelL.cekAkun(ILogin);
                    int checkusername = 0;
                    int checkpassword = 0;
                    for (int i = 0; i < DLogin.length; i++) {
                        if (DLogin[i][0].equals(ILogin[0])) {
                            checkusername = 1;

                            if (DLogin[i][1].equals(ILogin[1])) {
                                checkpassword = 1;
                                if (DLogin[i][2].equalsIgnoreCase("Manager")) {
                                    viewL.setVisible(false);
                                    new CMHomeManager(new VHomeManager());
                                } else if (DLogin[i][2].equalsIgnoreCase("Kasir")) {
                                    viewL.setVisible(false);
                                    String[] User = new String [2];
                                    User [0] = modelL.GetID(ILogin [0] , ILogin [1]);
                                    User [1] = DLogin[i][0] ;
                                    new CKHomeKasir(new VHomeKasir(), User);
                                } else if (DLogin[i][2].equalsIgnoreCase("PGudang")) {
                                    viewL.setVisible(false);
                                    String[] User = new String [2];
                                    User [0] = modelL.GetID(ILogin [0] , ILogin [1]);
                                    User [1] = DLogin[i][0] ;
                                    new CPHomePgudang(new VHomePgudang(),User) ;
                                }
                            }
                        }
                    }
                    if (checkusername == 0 || checkpassword == 0) {
                        viewL.showMessagePane("Username atau Password Salah");
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(CLogin.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }

    }

}
