package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Msupplier;
import view.VHomeManager;
import view.VMLihatKualitas;

public class CMLihatKualitas {

    VMLihatKualitas view ;
    Msupplier model ;
    
    public CMLihatKualitas(VMLihatKualitas view, Msupplier model ) throws SQLException {
        this.view = view;
        this.model = model;
        this.view.setVisible(true);
        this.view.setTableModel(this.model.getDataKualitas());

        this.view.BackLihatKualitas(new BackListener());
    }

    private class BackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
           new CMHomeManager(new VHomeManager());
            view.dispose();

        }

    }
}

