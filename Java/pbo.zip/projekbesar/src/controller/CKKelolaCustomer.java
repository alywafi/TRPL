package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Mcustomer;
import view.VHomeKasir;
import view.VKKelolaCustomer;

public class CKKelolaCustomer {

    String[] User;

    Mcustomer modelKelolaCustomer;
    VKKelolaCustomer viewKelolaCustomer;
    VHomeKasir viewHomeKasir;

    public CKKelolaCustomer(VKKelolaCustomer viewkelolacustomer, Mcustomer modelkelolacustomer, VHomeKasir viewhomekasir, String [] user) throws SQLException {
        
        this.User = user ;
        this.viewKelolaCustomer = viewkelolacustomer;
        this.modelKelolaCustomer = modelkelolacustomer;
        this.viewKelolaCustomer.setTableModel(this.modelKelolaCustomer.getData());
        this.viewKelolaCustomer.setVisible(true);
        this.viewKelolaCustomer.setSaveUpdateEnable(false);
        this.viewKelolaCustomer.setFieldIdEditable(false);

        this.viewKelolaCustomer.UpdateClick(new UpdateClickListener());
        this.viewKelolaCustomer.BackKelolaCustomer(new BackListener());
        this.viewKelolaCustomer.SaveCreateClick(new SimpanCreateListener());
        this.viewKelolaCustomer.SaveUpdateClick(new SimpanUpdateListener());

    }

    private class SimpanCreateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (modelKelolaCustomer.insertData(viewKelolaCustomer.getDataCreate())) { // Jika query insert pada model berhasil
                    viewKelolaCustomer.showMessagePane("Data Berhasil Di Simpan"); // menampilkan JOptionPane di Method showMessagePane pada view
                    viewKelolaCustomer.setTableModel(modelKelolaCustomer.getData()); // mengatur ulang isi Table
                } else {
                    viewKelolaCustomer.showMessagePane("Data Gagal Di Simpan");
                }
            } catch (SQLException ex) {
                viewKelolaCustomer.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class SimpanUpdateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {

                if (modelKelolaCustomer.updateData(viewKelolaCustomer.getDataUpdate())) { // Jika query update pada model berhasil
                    viewKelolaCustomer.showMessagePane("Data Berhasil Di Simpan");
                    viewKelolaCustomer.setTableModel(modelKelolaCustomer.getData()); //mengatur ulang isi tabel
                    viewKelolaCustomer.setDataUpdateKosong();
                    viewKelolaCustomer.setSaveUpdateEnable(false);
                    viewKelolaCustomer.setGantiEnable(true);

                } else {
                    viewKelolaCustomer.showMessagePane("Data Gagal Di Simpan");
                }

                // mengkosongkan fieldID dan namaStatus pada view
            } catch (SQLException ex) {
                viewKelolaCustomer.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class BackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CKHomeKasir(new VHomeKasir(), User);
            viewKelolaCustomer.dispose();
        }

    }

    private class UpdateClickListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewKelolaCustomer.getSelectedRow() == -1) {
                viewKelolaCustomer.showMessagePane("Pilih Dulu Cuy");
            } else {
                try {
                    String[] data = modelKelolaCustomer.getDataWithID(viewKelolaCustomer.getIdUser());
                    viewKelolaCustomer.setFieldIdEditable(false);
                    viewKelolaCustomer.setGantiEnable(false);
                    viewKelolaCustomer.setSaveUpdateEnable(true);

                    viewKelolaCustomer.setDataUpdate(data);

                } catch (SQLException ex) {
                    viewKelolaCustomer.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }
}
