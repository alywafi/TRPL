package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Mkaryawan;
import view.VHomeManager;
import view.VMKelolaKaryawan;
import view.VMKelolaUser;

/**
 *
 * @author USER
 */
public class CMKelolaKaryawan {

    Mkaryawan modelKelolaKaryawan;
    VMKelolaKaryawan viewKelolaKaryawan;
    VHomeManager viewHomeManager;

    public CMKelolaKaryawan(VMKelolaKaryawan viewkelolakaryawan, Mkaryawan modelkelolakaryawan, VHomeManager viewhomemanager) throws SQLException {
        this.viewKelolaKaryawan = viewkelolakaryawan;
        this.modelKelolaKaryawan = modelkelolakaryawan;
        this.viewKelolaKaryawan.setTableModel(this.modelKelolaKaryawan.getData());
        this.viewKelolaKaryawan.setVisible(true);
        this.viewKelolaKaryawan.setSaveUpdateEnable(false);
        this.viewKelolaKaryawan.setFieldIdEditable(false);

        this.viewKelolaKaryawan.UpdateClick(new UpdateClickListener());
        this.viewKelolaKaryawan.BackKelolaKaryawan(new BackListener());
        this.viewKelolaKaryawan.SaveCreateClick(new SimpanCreateListener());
        this.viewKelolaKaryawan.SaveUpdateClick(new SimpanUpdateListener());

    }

    private class SimpanCreateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
                try {
                    if (modelKelolaKaryawan.insertData(viewKelolaKaryawan.getDataCreate())) { // Jika query insert pada model berhasil
                        viewKelolaKaryawan.showMessagePane("Data Berhasil Di Simpan"); // menampilkan JOptionPane di Method showMessagePane pada view
                        viewKelolaKaryawan.setTableModel(modelKelolaKaryawan.getData()); // mengatur ulang isi Table
                    } else {
                        viewKelolaKaryawan.showMessagePane("Data Gagal Di Simpan");
                    }
                } catch (SQLException ex) {
                    viewKelolaKaryawan.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }

        }

        private class SimpanUpdateListener implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    if (modelKelolaKaryawan.updateData(viewKelolaKaryawan.getDataUpdate())) { // Jika query update pada model berhasil
                        viewKelolaKaryawan.showMessagePane("Data Berhasil Di Simpan");
                        viewKelolaKaryawan.setTableModel(modelKelolaKaryawan.getData()); //mengatur ulang isi tabel
                        viewKelolaKaryawan.setDataUpdateKosong();
                        viewKelolaKaryawan.setSaveUpdateEnable(false);
                        viewKelolaKaryawan.setGantiEnable(true);

                    } else {
                        viewKelolaKaryawan.showMessagePane("Data Gagal Di Simpan");
                    }

                    // mengkosongkan fieldID dan namaStatus pada view
                } catch (SQLException ex) {
                    viewKelolaKaryawan.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }

        }

        private class BackListener implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e) {
                new CMHomeManager(new VHomeManager());
                viewKelolaKaryawan.dispose();
            }

        }

        private class UpdateClickListener implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (viewKelolaKaryawan.getSelectedRow() == -1) {
                    viewKelolaKaryawan.showMessagePane("Pilih Dulu Cuy");
                } else {
                    try {
                        String[] data = modelKelolaKaryawan.getDataWithID(viewKelolaKaryawan.getIdUser());
                        viewKelolaKaryawan.setFieldIdEditable(false);
                        viewKelolaKaryawan.setGantiEnable(false);
                        viewKelolaKaryawan.setSaveUpdateEnable(true);

                        viewKelolaKaryawan.setDataUpdate(data);

                    } catch (SQLException ex) {
                        viewKelolaKaryawan.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                    }
                }
            }

        }

    }
