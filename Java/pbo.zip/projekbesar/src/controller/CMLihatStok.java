package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Mstok;
import view.VHomeKasir;
import view.VHomeManager;
import view.VMLihatStok;

public class CMLihatStok {

    String[] User;
    VMLihatStok view;
    Mstok model;

    public CMLihatStok(VMLihatStok view, Mstok model, String Aktor, String[] User) throws SQLException {
        this.User = User;
        this.view = view;
        this.model = model;
        this.view.setVisible(true);
        this.view.setTableModel(this.model.getData());
        if (Aktor == "manager") {
            this.view.BackMLihatStockClick(new BackManagerListener());
        } else {
            this.view.BackMLihatStockClick(new BackKasirListener());
        }

    }

    private class BackKasirListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CKHomeKasir(new VHomeKasir(), User);
            view.dispose();
        }
    }

    private class BackManagerListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CMHomeManager(new VHomeManager());
            view.dispose();

        }

    }
}
