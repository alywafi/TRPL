package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.Msupplier;
import view.VHomeManager;
import view.VHomePgudang;
import view.VMKelolaSupplier;

/**
 *
 * @author USER
 */
public class CMKelolaSupplier {
    String [] User ;

    Msupplier modelKelolaSupplier;
    VMKelolaSupplier viewKelolaSupplier;
    VHomeManager viewHomeManager;

    public CMKelolaSupplier(VMKelolaSupplier viewkelolasupplier, Msupplier modelkelolasupplier, VHomeManager viewhomemanager, String aktor, String [] user) throws SQLException {
        this.User = user ;
        this.viewKelolaSupplier = viewkelolasupplier;
        this.modelKelolaSupplier = modelkelolasupplier;
        this.viewKelolaSupplier.setTableModelKelolaSupplier(this.modelKelolaSupplier.getData());
        this.viewKelolaSupplier.setTableModelKualitas(this.modelKelolaSupplier.getDataKualitas());
        this.viewKelolaSupplier.setVisible(true);
        this.viewKelolaSupplier.setSaveUpdateEnable(false);
        this.viewKelolaSupplier.setFieldIdEditable(false);
        if (aktor == "manager") {
            this.viewKelolaSupplier.setJTabCreateEnable(true, 0);
            this.viewKelolaSupplier.BackKelolaSupplier(new BackManagerListener());
        } else {
            this.viewKelolaSupplier.BackKelolaSupplier(new BackPgudangListener());
            this.viewKelolaSupplier.setJTabCreateEnable(false, 1);
        }

        this.viewKelolaSupplier.UpdateClick(new UpdateClickListener());
        this.viewKelolaSupplier.SaveCreateClick(new SimpanCreateListener());
        this.viewKelolaSupplier.SaveUpdateClick(new SimpanUpdateListener());

    }

    private class SimpanCreateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (modelKelolaSupplier.insertData(viewKelolaSupplier.getDataCreate())) {
                    viewKelolaSupplier.showMessagePane("Data Berhasil Di Simpan");
                    viewKelolaSupplier.setTableModelKelolaSupplier(modelKelolaSupplier.getData()); // mengatur ulang isi Table
                    viewKelolaSupplier.setTableModelKualitas(modelKelolaSupplier.getDataKualitas()); // mengatur ulang isi Table
                } else {
                    viewKelolaSupplier.showMessagePane("Data Gagal Di Simpan");
                }
            } catch (SQLException ex) {
                viewKelolaSupplier.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class SimpanUpdateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {

                if (modelKelolaSupplier.updateData(viewKelolaSupplier.getDataUpdate())) { // Jika query update pada model berhasil
                    viewKelolaSupplier.showMessagePane("Data Berhasil Di Simpan");
                    viewKelolaSupplier.setTableModelKelolaSupplier(modelKelolaSupplier.getData()); //mengatur ulang isi tabel
                    viewKelolaSupplier.setTableModelKualitas(modelKelolaSupplier.getDataKualitas()); //mengatur ulang isi tabel
                    viewKelolaSupplier.setDataUpdateKosong();
                    viewKelolaSupplier.setSaveUpdateEnable(false);
                    viewKelolaSupplier.setGantiEnable(true);

                } else {
                    viewKelolaSupplier.showMessagePane("Data Gagal Di Simpan");
                }

                // mengkosongkan fieldID dan namaStatus pada view
            } catch (SQLException ex) {
                viewKelolaSupplier.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class BackManagerListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CMHomeManager(new VHomeManager());
            viewKelolaSupplier.dispose();
        }

    }

    private class BackPgudangListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CPHomePgudang(new VHomePgudang(), User);
            viewKelolaSupplier.dispose();
        }

    }

    private class UpdateClickListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewKelolaSupplier.getSelectedRow() == -1) {
                viewKelolaSupplier.showMessagePane("Pilih Dulu Cuy");
            } else {
                try {
                    String[] data = modelKelolaSupplier.getDataWithID(viewKelolaSupplier.getIdUser());
                    viewKelolaSupplier.setFieldIdEditable(false);
                    viewKelolaSupplier.setGantiEnable(false);
                    viewKelolaSupplier.setSaveUpdateEnable(true);

                    viewKelolaSupplier.setDataUpdate(data);

                } catch (SQLException ex) {
                    viewKelolaSupplier.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

}
