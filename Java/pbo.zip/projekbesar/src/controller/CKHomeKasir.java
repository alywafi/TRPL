/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import model.Mcustomer;
import model.Mtransaksi;
import model.Mkaryawan;
import model.Mstok;
import view.VHomeKasir;
import view.VHomeManager;
import view.VHomePgudang;
import view.VKKelolaCustomer;
import view.VKModeKasir;
import view.VLogin;
import view.VMLihatStok;

/**
 *
 * @author USER
 */
public class CKHomeKasir {

    String[] user = new String[2];
    VHomeKasir viewHomeKasir;

    public CKHomeKasir(VHomeKasir viewhomekasir, String[] User) {
        this.viewHomeKasir = viewhomekasir;
        this.viewHomeKasir.setVisible(true);
        this.user = User;

        this.viewHomeKasir.setNama(user);

        this.viewHomeKasir.KelolaCustomerKClick(new KelolaCustomerListener());
        this.viewHomeKasir.LogoutKKClick(new LogoutListener());
        this.viewHomeKasir.LihatStockKClick(new LihatStokListener());
        this.viewHomeKasir.MasukModeKasir(new ModeKasirListener());
    }

    private class ModeKasirListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                new CKModeKasir(new VKModeKasir(), new Mtransaksi(), user);
            } catch (SQLException ex) {
                Logger.getLogger(CKHomeKasir.class.getName()).log(Level.SEVERE, null, ex);
            }
            viewHomeKasir.dispose();
        }

    }

    private class LihatStokListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            try {
                new CMLihatStok(new VMLihatStok(), new Mstok(), "Kasir", user);
                viewHomeKasir.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(CKHomeKasir.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    private class LogoutListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomeKasir.dispose();
                new CLogin(new VLogin(), new Mkaryawan());
            } catch (SQLException ex) {
                Logger.getLogger(CKHomeKasir.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class KelolaCustomerListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomeKasir.dispose();
                new CKKelolaCustomer(new VKKelolaCustomer(), new Mcustomer(), new VHomeKasir(), user);
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
    /*
    private class KelolaSupplierListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                viewHomePgudang.dispose();
                new CMKelolaSupplier(new VMKelolaSupplier(), new MMKelolaSupplier(), new VHomeManager(), "pgudang");
            } catch (SQLException ex) {
                Logger.getLogger(CMHomeManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
     */
}
