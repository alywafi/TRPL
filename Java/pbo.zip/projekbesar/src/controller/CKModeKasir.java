package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Mtransaksi;
import view.VHomeKasir;
import view.VKModeKasir;

/**
 *
 * @author USER
 */
public class CKModeKasir {

    String[] user;

    VKModeKasir viewModeKasir;
    Mtransaksi modelModeKasir;

    public CKModeKasir(VKModeKasir viewmodekasir, Mtransaksi modelmodekasir, String[] User) throws SQLException {
        this.user = User;
        this.viewModeKasir = viewmodekasir;
        this.modelModeKasir = modelmodekasir;

        this.viewModeKasir.setId(User[0]);
        this.viewModeKasir.setNama(User[1]);
        this.viewModeKasir.setKaryawanID(User[0]);
        this.viewModeKasir.setTransaksiID(modelmodekasir.GetId());

        this.viewModeKasir.setVisible(true);
        this.viewModeKasir.setTableModelJenisIkan(this.modelModeKasir.getDataJenisIkan());
        this.viewModeKasir.setDefaultTableModelTransaksi();

        this.viewModeKasir.setSaveEnable(false);
        this.viewModeKasir.setInsertToTableEnable(false);
        this.viewModeKasir.setFieldIdEditable(false);

        this.viewModeKasir.SaveTransaksiClick(new SaveTransaksiListener());
        this.viewModeKasir.BackKelolaStock(new BackListener());
        this.viewModeKasir.ResetTransaksiClick(new ResetTransaksiListener());
        this.viewModeKasir.InsertIkanToTableClick(new InsertIkanToTableListener());
        this.viewModeKasir.InsertIkanToJTClick(new InsertIkanToJTListener());

    }

    private class ResetTransaksiListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            viewModeKasir.setReset();

        }
    }

    private class InsertIkanToTableListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewModeKasir.getStatusJTQuantity().isEmpty()) {
                viewModeKasir.showMessagePane("isi dulu jumlah pembeliannya cuy");
            } else {

                viewModeKasir.addRowTableModelTransaksi(viewModeKasir.getDataJenisIkanFromJT());
                viewModeKasir.setResetInserttoTableTransaksi();
                viewModeKasir.setSaveEnable(true);
            }
        }
    }

    private class InsertIkanToJTListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewModeKasir.getSelectedRow() == -1) {
                viewModeKasir.showMessagePane("Pilih Dulu Cuy");
            } else {
                try {
                    String[] data = modelModeKasir.getDataWithID(viewModeKasir.getIdUser());
                    viewModeKasir.setInsertToTableEnable(true);
                    viewModeKasir.SetToJTJenisIkan(data);

                } catch (SQLException ex) {
                    viewModeKasir.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }

        }
    }

    private class BackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CKHomeKasir(new VHomeKasir(), user);
            viewModeKasir.dispose();
        }

    }

    private class SaveTransaksiListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            if (!viewModeKasir.getSupplierEmpty()) {

                try {
                    if (modelModeKasir.insertData(viewModeKasir.getDataForDBTransaksi())) { // Jika query update pada model berhasil
                    } else {
                        viewModeKasir.showMessagePane("Data Gagal Di Simpan wkwkkw");
                    }

                } catch (SQLException ex) {
                    viewModeKasir.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }

                String da[][] = viewModeKasir.getDataTransaksiTable();
                for (int i = 0; i < da.length; i++) {
                    String DataInput[] = new String[3];
                    String d[] = new String[2];

                    for (int j = 0; j < 2; j++) {
                        d[j] = da[i][j];
                        DataInput[j + 1] = da[i][j + 1];
                    }

                    try {
                        DataInput[0] = modelModeKasir.getIDWithData(d);
                        if (modelModeKasir.insertDataToDetailed(viewModeKasir.getTransaksiID(), DataInput)) { // Jika query update pada model berhasil
                        } else {
                            viewModeKasir.showMessagePane("Data Gagal Di Simpan COYY");
                        }

                    } catch (SQLException ex) {
                        viewModeKasir.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                    }

                }
                viewModeKasir.showMessagePane("Data Berhasil Disimpan");
                try {
                    viewModeKasir.setTableModelJenisIkan(modelModeKasir.getDataJenisIkan());
                } catch (SQLException ex) {
                    Logger.getLogger(CKModeKasir.class.getName()).log(Level.SEVERE, null, ex);
                }
                viewModeKasir.setReset();
            } else {
                viewModeKasir.showMessagePane("Suppliernya Isi DUlu Bos");

            }
        }
    }
}
