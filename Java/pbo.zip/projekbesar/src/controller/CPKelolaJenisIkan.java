/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import model.MjenisIkan;
import view.VHomePgudang;
import view.VMKelolaSupplier;
import view.VPKelolaJenisIkan;

/**
 *
 * @author USER
 */
public class CPKelolaJenisIkan {
    String [] User ;

    MjenisIkan modelKelolaJenisIkan;
    VPKelolaJenisIkan viewKelolaJenisIkan;
    VHomePgudang viewHomePgudang;

    public CPKelolaJenisIkan(MjenisIkan modelkelolajenisikan, VPKelolaJenisIkan viewkelolajenisikan , String [] user ) throws SQLException {
        this.User = user ;
        this.viewKelolaJenisIkan = viewkelolajenisikan;
        this.modelKelolaJenisIkan = modelkelolajenisikan;
        this.viewKelolaJenisIkan.setTableModel(this.modelKelolaJenisIkan.getData());
        this.viewKelolaJenisIkan.setVisible(true);
        this.viewKelolaJenisIkan.setSaveUpdateEnable(false);
        this.viewKelolaJenisIkan.setFieldIdEditable(false);

        this.viewKelolaJenisIkan.UpdateClick(new UpdateClickListener());
        this.viewKelolaJenisIkan.BackKelolaJenisIkan(new BackListener());
        this.viewKelolaJenisIkan.SaveCreateClick(new SimpanCreateListener());
        this.viewKelolaJenisIkan.SaveUpdateClick(new SimpanUpdateListener());

    }

    private class SimpanCreateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                if (modelKelolaJenisIkan.insertData(viewKelolaJenisIkan.getDataCreate())) {
                    viewKelolaJenisIkan.showMessagePane("Data Berhasil Di Simpan");
                    viewKelolaJenisIkan.setTableModel(modelKelolaJenisIkan.getData()); // mengatur ulang isi Table
                    viewKelolaJenisIkan.setTableModel(modelKelolaJenisIkan.getData()); // mengatur ulang isi Table
                } else {
                    viewKelolaJenisIkan.showMessagePane("Data Gagal Di Simpan");
                }
            } catch (SQLException ex) {
                viewKelolaJenisIkan.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class SimpanUpdateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {

                if (modelKelolaJenisIkan.updateData(viewKelolaJenisIkan.getDataUpdate())) { // Jika query update pada model berhasil
                    viewKelolaJenisIkan.showMessagePane("Data Berhasil Di Simpan");
                    viewKelolaJenisIkan.setTableModel(modelKelolaJenisIkan.getData()); //mengatur ulang isi tabel
                    viewKelolaJenisIkan.setDataUpdateKosong();
                    viewKelolaJenisIkan.setSaveUpdateEnable(false);
                    viewKelolaJenisIkan.setGantiEnable(true);

                } else {
                    viewKelolaJenisIkan.showMessagePane("Data Gagal Di Simpan");
                }

                // mengkosongkan fieldID dan namaStatus pada view
            } catch (SQLException ex) {
                viewKelolaJenisIkan.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
            }
        }

    }

    private class BackListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            new CPHomePgudang(new VHomePgudang(), User);
            viewKelolaJenisIkan.dispose();
        }

    }

    private class UpdateClickListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewKelolaJenisIkan.getSelectedRow() == -1) {
                viewKelolaJenisIkan.showMessagePane("Pilih Dulu Cuy");
            } else {
                try {
                    String[] data = modelKelolaJenisIkan.getDataWithID(viewKelolaJenisIkan.getIdUser());
                    viewKelolaJenisIkan.setFieldIdEditable(false);
                    viewKelolaJenisIkan.setGantiEnable(false);
                    viewKelolaJenisIkan.setSaveUpdateEnable(true);

                    viewKelolaJenisIkan.setDataUpdate(data);

                } catch (SQLException ex) {
                    viewKelolaJenisIkan.showMessagePane("Eror !, Tidak Dapat Menjalankan Query");
                }
            }
        }

    }

}
