package projekbesar;

import controller.CLogin;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import model.Mkaryawan;
import view.VHomeKasir;
import view.VHomeManager;
import view.VHomePgudang;
import view.VLogin;

public class Projekbesar {

    public static void main(String[] args) throws SQLException {
                new CLogin(new VLogin(),new Mkaryawan() );

    
    }

}
