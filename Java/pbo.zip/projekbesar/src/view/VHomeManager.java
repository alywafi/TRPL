/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.ActionListener;

/**
 *
 * @author USER
 */
public class VHomeManager extends javax.swing.JFrame {

    /**
     * Creates new form vHomeManager
     */
    public VHomeManager() {
        initComponents();
                this.setLocationRelativeTo(this);
    }

    public void KelolaUserClick(ActionListener action){
        this.btnmuser.addActionListener(action);
    }
    public void KelolaSupplierClick (ActionListener action){
        this.btnmsupplier.addActionListener(action);
    }
    public void KelolaKaryawanClick (ActionListener action){
        this.btnmkaryawan.addActionListener(action);
    }
    public void LihatStockMClick (ActionListener action){
        this.btnmstok.addActionListener(action);
    }
    public void LihatTransaksiClick (ActionListener action){
        this.btnmtransaksi.addActionListener(action);
    }
    public void LihatKualitasClick (ActionListener action){
        this.btnmkualitas.addActionListener(action);
    }
    public void LogoutMClick (ActionListener action){
        this.btnmlogout.addActionListener(action);
    }
    public void setNama (String data){
        this.LMnama.setText(data);
    }
 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnmuser = new javax.swing.JButton();
        btnmkaryawan = new javax.swing.JButton();
        btnmsupplier = new javax.swing.JButton();
        btnmstok = new javax.swing.JButton();
        btnmtransaksi = new javax.swing.JButton();
        btnmkualitas = new javax.swing.JButton();
        LMnama = new javax.swing.JLabel();
        btnmlogout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1300, 850));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnmuser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanager.png"))); // NOI18N
        btnmuser.setBorderPainted(false);
        btnmuser.setContentAreaFilled(false);
        btnmuser.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanagerroll.png"))); // NOI18N
        getContentPane().add(btnmuser, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 510, -1, -1));

        btnmkaryawan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanager.png"))); // NOI18N
        btnmkaryawan.setBorderPainted(false);
        btnmkaryawan.setContentAreaFilled(false);
        btnmkaryawan.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanagerroll.png"))); // NOI18N
        getContentPane().add(btnmkaryawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 510, -1, -1));

        btnmsupplier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanager.png"))); // NOI18N
        btnmsupplier.setBorderPainted(false);
        btnmsupplier.setContentAreaFilled(false);
        btnmsupplier.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanagerroll.png"))); // NOI18N
        getContentPane().add(btnmsupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 510, -1, -1));

        btnmstok.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnstok.png"))); // NOI18N
        btnmstok.setBorderPainted(false);
        btnmstok.setContentAreaFilled(false);
        btnmstok.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnstokroll.png"))); // NOI18N
        getContentPane().add(btnmstok, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 410, -1, -1));

        btnmtransaksi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnTransaksi.png"))); // NOI18N
        btnmtransaksi.setBorderPainted(false);
        btnmtransaksi.setContentAreaFilled(false);
        btnmtransaksi.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnTransaksiroll.png"))); // NOI18N
        getContentPane().add(btnmtransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 530, -1, -1));

        btnmkualitas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnKualitas.png"))); // NOI18N
        btnmkualitas.setBorderPainted(false);
        btnmkualitas.setContentAreaFilled(false);
        btnmkualitas.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnKualitasroll.png"))); // NOI18N
        getContentPane().add(btnmkualitas, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 640, -1, -1));

        LMnama.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        LMnama.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(LMnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 110, 140, 20));

        btnmlogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnlogout.png"))); // NOI18N
        btnmlogout.setBorderPainted(false);
        btnmlogout.setContentAreaFilled(false);
        btnmlogout.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnlogoutroll.png"))); // NOI18N
        getContentPane().add(btnmlogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 170, 120, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ahir_vhomemanager.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VHomeManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VHomeManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VHomeManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VHomeManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VHomeManager().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LMnama;
    private javax.swing.JButton btnmkaryawan;
    private javax.swing.JButton btnmkualitas;
    private javax.swing.JButton btnmlogout;
    private javax.swing.JButton btnmstok;
    private javax.swing.JButton btnmsupplier;
    private javax.swing.JButton btnmtransaksi;
    private javax.swing.JButton btnmuser;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
