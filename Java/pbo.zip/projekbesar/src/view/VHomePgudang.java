/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.ActionListener;

/**
 *
 * @author USER
 */
public class VHomePgudang extends javax.swing.JFrame {

    /**
     * Creates new form vHomePgudang
     */
    public VHomePgudang() {
        initComponents();
        this.setLocationRelativeTo(this);
    }

    public VHomePgudang(String string, String string0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    public void KelolaStockClick(ActionListener action) {
        this.btnpkelolastok.addActionListener(action);
    }

    public void KelolaJenisIkanClick(ActionListener action) {
        this.btnpjenisikan.addActionListener(action);
    }

    public void KelolaSupplierClick(ActionListener action) {
        this.btnpsupplier.addActionListener(action);
    }

    public void logoutPClick(ActionListener action) {
        this.btnplogout.addActionListener(action);
    }

    public void setNama(String data) {
        this.LPnama.setText(data);
    }
    public void setID(String data) {
        this.LPid.setText(data);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnpkelolastok = new javax.swing.JButton();
        btnpsupplier = new javax.swing.JButton();
        btnpjenisikan = new javax.swing.JButton();
        btnplogout = new javax.swing.JButton();
        LPnama = new javax.swing.JLabel();
        LPid = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1300, 850));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnpkelolastok.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanager.png"))); // NOI18N
        btnpkelolastok.setBorderPainted(false);
        btnpkelolastok.setContentAreaFilled(false);
        btnpkelolastok.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnkelolamanagerroll.png"))); // NOI18N
        getContentPane().add(btnpkelolastok, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 460, -1, -1));

        btnpsupplier.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnpsupplier.png"))); // NOI18N
        btnpsupplier.setBorderPainted(false);
        btnpsupplier.setContentAreaFilled(false);
        btnpsupplier.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnpsupplierroll.png"))); // NOI18N
        getContentPane().add(btnpsupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 520, -1, -1));

        btnpjenisikan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnpjenisikan.png"))); // NOI18N
        btnpjenisikan.setBorderPainted(false);
        btnpjenisikan.setContentAreaFilled(false);
        btnpjenisikan.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnpjenisikanroll.png"))); // NOI18N
        getContentPane().add(btnpjenisikan, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 640, -1, -1));

        btnplogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnlogout.png"))); // NOI18N
        btnplogout.setBorderPainted(false);
        btnplogout.setContentAreaFilled(false);
        btnplogout.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnlogoutroll.png"))); // NOI18N
        getContentPane().add(btnplogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1157, 170, 130, -1));

        LPnama.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        getContentPane().add(LPnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 100, 130, 30));

        LPid.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        getContentPane().add(LPid, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 90, 120, 20));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ahir_vhomepgudang.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VHomePgudang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VHomePgudang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VHomePgudang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VHomePgudang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VHomePgudang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LPid;
    private javax.swing.JLabel LPnama;
    private javax.swing.JButton btnpjenisikan;
    private javax.swing.JButton btnpkelolastok;
    private javax.swing.JButton btnplogout;
    private javax.swing.JButton btnpsupplier;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
