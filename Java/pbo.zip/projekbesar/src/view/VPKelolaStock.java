package view;

import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VPKelolaStock extends javax.swing.JFrame {

    /**
     * Creates new form vLihatStok
     */
    public VPKelolaStock() {
        initComponents();
        this.setLocationRelativeTo(this);
    }

    public void setTableModelJenisIkan(DefaultTableModel table) {
        this.TMJenisIkan.setModel(table);
    }

    public void setDefaultTableModelStok() {
        DefaultTableModel aa = new DefaultTableModel(0, 0);
        TMStok.setModel(aa);
    }

    public void BackKelolaStock(ActionListener action) {
        this.btnback.addActionListener(action);
    }

    public void InsertIkanToJTClick(ActionListener action) {
        this.btnInsertIkanToJT.addActionListener(action);
    }

    public void InsertIkanToTableClick(ActionListener action) {
        this.btnInserttotablestok.addActionListener(action);
    }

    public void SaveStokClick(ActionListener action) {
        this.btnsavestok.addActionListener(action);
    }

    public void ResetStokClick(ActionListener action) {
        this.btnResetStok.addActionListener(action);
    }

    public String[] getDataJenisIkanFromJT() {
        String data[] = new String[3];
        data[0] = this.jtNamaInsertToTable.getText();
        data[1] = this.jtHargaInsertToTable.getText();
        data[2] = this.jtQuantityInsertToTable.getText();
        return data;
    }

    public String[] getDataForDBStok() {
        String data[] = new String[4];
        data[0] = this.jtStokID.getText();
        data[1] = this.jtKaryawanID.getText();
        data[2] = this.jtSupplierID.getText();
        Date s = new Date();
        SimpleDateFormat kal = new SimpleDateFormat("yyyy/dd/MM");
        data[3] = kal.format(s);
        return data;
    }

    public String getStokID() {
        String StokID = this.jtStokID.getText();
        return StokID;
    }

    public String[][] getDataStokTable() {
        String data[][] = new String[this.TMStok.getRowCount()][3];
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < 3; j++) {
                data[i][j] = String.valueOf(this.TMStok.getValueAt(i, j));
            }
        }
        return data;
    }

    public DefaultTableModel getmodelstok() {
        return (DefaultTableModel) TMStok.getModel();
    }

    public void addRowTableModelStok(String data[]) {
        String kolom[] = {"Nama", "Harga", "Quantity", "Jumlah"};
        DefaultTableModel model = new DefaultTableModel(null, kolom);
        String dataawal[] = new String[4];
        if (TMStok.getRowCount() > 0) {
            for (int i = 0; i < TMStok.getRowCount(); i++) {
                for (int j = 0; j < dataawal.length; j++) {
                    dataawal[j] = (String) TMStok.getValueAt(i, j);
                }
                model.addRow(dataawal);
            }
        }
        for (int i = 0; i < 3; i++) {
            dataawal[i] = data[i];
        }
        dataawal[3] = String.valueOf(Integer.valueOf(data[1]) * Integer.valueOf(data[2]));
        model.addRow(dataawal);
        TMStok.setModel(model);
    }

    public String getStatusJTQuantity() {
        String status = jtQuantityInsertToTable.getText();

        return status;
    }

    public void SetToJTJenisIkan(String data[]) {
        this.jtNamaInsertToTable.setText(data[0]);
        this.jtHargaInsertToTable.setText(data[1]);
    }

    public void setStokID(String data) {
        this.jtStokID.setText(data);
    }

    public void setKaryawanID(String data) {
        this.jtKaryawanID.setText(data);
    }

    public void showMessagePane(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public void setReset() {
        this.jtSupplierID.setText("");
        this.jtNamaInsertToTable.setText("");
        this.jtHargaInsertToTable.setText("");
        this.jtQuantityInsertToTable.setText("");
        this.btnInserttotablestok.setEnabled(false);
        this.btnsavestok.setEnabled(false);
        TMStok.setModel(new DefaultTableModel());

    }

    public void setResetInserttoTableStok() {
        this.jtNamaInsertToTable.setText("");
        this.jtHargaInsertToTable.setText("");
        this.jtQuantityInsertToTable.setText("");
    }

    public int getSelectedRow() {
        return this.TMJenisIkan.getSelectedRow();
    }

    public String getIdUser() {
        return (String) this.TMJenisIkan.getValueAt(this.getSelectedRow(), 0);
    }

    public void setFieldIdEditable(boolean editable) {
        this.jtStokID.setEditable(editable);
        this.jtKaryawanID.setEditable(editable);
        this.jtNamaInsertToTable.setEditable(editable);
        this.jtHargaInsertToTable.setEditable(editable);
    }

    public void setSaveEnable(boolean enable) {
        this.btnsavestok.setEnabled(enable);
    }

    public void setInsertToTableEnable(boolean enable) {
        this.btnInserttotablestok.setEnabled(enable);
    }

    public void setNama(String data) {
        this.LPNama.setText(data);
    }

    public void setId(String data) {
        this.LPid.setText(data);
    }

    public String[] getKualitas() {
        String[] kua = new String[2];
        kua[0] = this.jtSupplierID.getText();
        kua[1] = this.jtKualitas.getText();
        return kua;
    }

    public boolean getSupplierEmpty() {
        boolean haha = false;
        if (this.jtSupplierID.getText().isEmpty()) {
            haha = true;
        }
        return haha;
    }

    public boolean getKualitasEmpty() {
        boolean haha = false;
        if (this.jtKualitas.getText().isEmpty()) {
            haha = true;
        }
        return haha;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnback = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jtStokID = new javax.swing.JTextField();
        jtKaryawanID = new javax.swing.JTextField();
        jtSupplierID = new javax.swing.JTextField();
        btnsavestok = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TMJenisIkan = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        TMStok = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jtQuantityInsertToTable = new javax.swing.JTextField();
        btnInserttotablestok = new javax.swing.JButton();
        btnInsertIkanToJT = new javax.swing.JButton();
        btnResetStok = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jtNamaInsertToTable = new javax.swing.JTextField();
        jtHargaInsertToTable = new javax.swing.JTextField();
        LPid = new javax.swing.JLabel();
        LPNama = new javax.swing.JLabel();
        jtKualitas = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnback.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnback.png"))); // NOI18N
        btnback.setBorderPainted(false);
        btnback.setContentAreaFilled(false);
        btnback.setName(""); // NOI18N
        btnback.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnbackroll.png"))); // NOI18N
        getContentPane().add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 140));
        btnback.getAccessibleContext().setAccessibleDescription("");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Supplier_ID");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 210, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Karyawan_ID");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, -1, -1));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Stok_ID");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, -1, -1));
        getContentPane().add(jtStokID, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 100, -1));
        getContentPane().add(jtKaryawanID, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 110, -1));
        getContentPane().add(jtSupplierID, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 90, -1));

        btnsavestok.setText("Save");
        getContentPane().add(btnsavestok, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 680, 350, 80));

        TMJenisIkan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nama", "Harga / kg", "Stok"
            }
        ));
        jScrollPane1.setViewportView(TMJenisIkan);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(832, 200, 420, 560));

        TMStok.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TMStok.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nama Ikan", "Harga / kg", "Quantity", "total"
            }
        ));
        TMStok.setShowHorizontalLines(false);
        jScrollPane2.setViewportView(TMStok);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, 330, 400));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Quantity");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 300, -1, -1));
        getContentPane().add(jtQuantityInsertToTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 320, 100, -1));

        btnInserttotablestok.setText("insert");
        getContentPane().add(btnInserttotablestok, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 320, 100, -1));

        btnInsertIkanToJT.setText("Add Ikan");
        getContentPane().add(btnInsertIkanToJT, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 200, -1, -1));

        btnResetStok.setText("reset");
        getContentPane().add(btnResetStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 680, -1, 80));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Nama Ikan");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, -1, -1));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Harga / kg");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 300, -1, -1));
        getContentPane().add(jtNamaInsertToTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 100, -1));
        getContentPane().add(jtHargaInsertToTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 320, 110, -1));
        getContentPane().add(LPid, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 100, 50, 20));
        getContentPane().add(LPNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 130, 50, 20));
        getContentPane().add(jtKualitas, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 230, 90, -1));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Kualitas (0-100)");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ahir_BGforall.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VPKelolaStock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VPKelolaStock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VPKelolaStock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VPKelolaStock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VPKelolaStock().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LPNama;
    private javax.swing.JLabel LPid;
    private javax.swing.JTable TMJenisIkan;
    private javax.swing.JTable TMStok;
    private javax.swing.JButton btnInsertIkanToJT;
    private javax.swing.JButton btnInserttotablestok;
    private javax.swing.JButton btnResetStok;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnsavestok;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jtHargaInsertToTable;
    private javax.swing.JTextField jtKaryawanID;
    private javax.swing.JTextField jtKualitas;
    private javax.swing.JTextField jtNamaInsertToTable;
    private javax.swing.JTextField jtQuantityInsertToTable;
    private javax.swing.JTextField jtStokID;
    private javax.swing.JTextField jtSupplierID;
    // End of variables declaration//GEN-END:variables
}
