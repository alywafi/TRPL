
package view;

import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class VMKelolaKaryawan extends javax.swing.JFrame {

    public VMKelolaKaryawan() {
        initComponents();
                this.setLocationRelativeTo(this);
    }

    public void BackKelolaKaryawan(ActionListener action){
        this.btnback.addActionListener(action);
    }
    public void UpdateClick(ActionListener action) {
        this.btnGanti.addActionListener(action);
    }

    public void SaveCreateClick(ActionListener action) {
        this.btnsavecreate.addActionListener(action);
    }
    public void SaveUpdateClick(ActionListener action) {
        this.btnSaveUpdate.addActionListener(action);
    }

    public String[] getDataCreate() {
        String data[] = new String[5]; 
        data[0] = this.jtNamaCreate.getText();
        data[1] = this.jtAlamatCreate.getText();
        data[2] = (String) this.jcjJabatanCreate.getSelectedItem() ;
        data[3] = this.jtNoHPCreate.getText();
        data[4] = this.JtPasswordCreate.getText();
        return data;
    }
    public String[] getDataUpdate() {
        String data[] = new String[5]; 
        data[0] = this.jtIdUpdate.getText();
        data[1] = this.jtNamaUpdate.getText();
        data[2] = this.jtAlamatUpdate.getText();
        data[3] = (String) this.jcJabatanUpdate.getSelectedItem() ;
        data[4] = this.jtNoHPUpdate.getText();
        return data;
    }

    public void setDataUpdate(String [] update) {
        this.jtIdUpdate.setText(update [0]);
        this.jtNamaUpdate.setText(update [1]);
        this.jtAlamatUpdate.setText(update [2]);
        this.jcJabatanUpdate.setSelectedItem(update [3]);
        this.jtNoHPUpdate.setText(update [4]);
    }
    public void setDataUpdateKosong() {
        this.jtIdUpdate.setText("");
        this.jtNamaUpdate.setText("");
        this.jtAlamatUpdate.setText("");
        this.jtNoHPUpdate.setText("");
    }
    public void setDataCreateKosong () {
        this.jtNamaCreate.setText("");
        this.jtAlamatCreate.setText("");
        this.jtNoHPCreate.setText("");
        this.JtPasswordCreate.setText("");
    }

    public void setTableModel(DefaultTableModel table) {
        this.TMKaryawar.setModel(table);
    }

    public void showMessagePane(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public int getSelectedRow() {
        return this.TMKaryawar.getSelectedRow();
    }

    public String getIdUser() {
        return (String) this.TMKaryawar.getValueAt(this.getSelectedRow(), 0) ;
    }

    public void setFieldIdEditable(boolean editable) {
        this.jtIdUpdate.setEditable(editable);
    }

    public void setGantiEnable(boolean enable) {
        this.btnGanti.setEnabled(enable);
    }
    public void setSaveUpdateEnable(boolean enable) {
        this.btnSaveUpdate.setEnabled(enable);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnback = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TMKaryawar = new javax.swing.JTable();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jtNamaCreate = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jtAlamatCreate = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jcjJabatanCreate = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jtNoHPCreate = new javax.swing.JTextField();
        btnsavecreate = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        JtPasswordCreate = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jtNamaUpdate = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jtAlamatUpdate = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jtNoHPUpdate = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jtIdUpdate = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btnSaveUpdate = new javax.swing.JButton();
        jcJabatanUpdate = new javax.swing.JComboBox<>();
        btnGanti = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnback.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnback.png"))); // NOI18N
        btnback.setBorderPainted(false);
        btnback.setContentAreaFilled(false);
        btnback.setName(""); // NOI18N
        btnback.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnbackroll.png"))); // NOI18N
        getContentPane().add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 140));
        btnback.getAccessibleContext().setAccessibleDescription("");

        TMKaryawar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nama", "Alamat", "Jabatan", "NoHP"
            }
        ));
        jScrollPane1.setViewportView(TMKaryawar);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setText("Nama");

        jLabel3.setText("Alamat");

        jLabel4.setText("Jabatan");

        jcjJabatanCreate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manager", "Kasir", "PGudang" }));
        jcjJabatanCreate.setSelectedIndex(1);
        jcjJabatanCreate.setToolTipText("");

        jLabel5.setText("NoHP");

        btnsavecreate.setText("Save");

        jLabel11.setText("Password");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jtNamaCreate, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnsavecreate, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jtAlamatCreate, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3)
                        .addComponent(jLabel5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 120, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jcjJabatanCreate, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(JtPasswordCreate, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jtNoHPCreate, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtNamaCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JtPasswordCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtAlamatCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jcjJabatanCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtNoHPCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addComponent(btnsavecreate)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Tambah Data", jPanel1);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setText("ID");

        jLabel7.setText("Nama");

        jLabel8.setText("NoHP");

        jLabel9.setText("Alamat");

        jLabel10.setText("Jabatan");

        btnSaveUpdate.setText("Save");

        jcJabatanUpdate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manager", "Kasir", "PGudang" }));
        jcJabatanUpdate.setSelectedIndex(1);
        jcJabatanUpdate.setToolTipText("");

        btnGanti.setText("Ganti");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnGanti, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(btnSaveUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtAlamatUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtNamaUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jtIdUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 98, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jtNoHPUpdate)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10)
                            .addComponent(jcJabatanUpdate, 0, 176, Short.MAX_VALUE))
                        .addGap(49, 49, 49))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jtIdUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtNamaUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtNoHPUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(7, 7, 7)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtAlamatUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jcJabatanUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveUpdate)
                    .addComponent(btnGanti))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Ubah Data", jPanel2);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 210, 530, 280));
        jTabbedPane1.getAccessibleContext().setAccessibleName("Create");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ahir_BGforall.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VMKelolaKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VMKelolaKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VMKelolaKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VMKelolaKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VMKelolaKaryawan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField JtPasswordCreate;
    private javax.swing.JTable TMKaryawar;
    private javax.swing.JButton btnGanti;
    private javax.swing.JButton btnSaveUpdate;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnsavecreate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JComboBox<String> jcJabatanUpdate;
    private javax.swing.JComboBox<String> jcjJabatanCreate;
    private javax.swing.JTextField jtAlamatCreate;
    private javax.swing.JTextField jtAlamatUpdate;
    private javax.swing.JTextField jtIdUpdate;
    private javax.swing.JTextField jtNamaCreate;
    private javax.swing.JTextField jtNamaUpdate;
    private javax.swing.JTextField jtNoHPCreate;
    private javax.swing.JTextField jtNoHPUpdate;
    // End of variables declaration//GEN-END:variables
}
