/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USER
 */
public class VMKelolaUser extends javax.swing.JFrame {

    /**
     * Creates new form vLihatStok
     */
    public VMKelolaUser() {
        initComponents();
        this.setLocationRelativeTo(this);
    }

    public void BackKelolaUser(ActionListener action) {
        this.btnback.addActionListener(action);
    }

    public void UpdateClick(ActionListener action) {
        this.btnmganti.addActionListener(action);
    }

    public void SaveClick(ActionListener action) {
        this.btnmsave.addActionListener(action);
    }

    public void getUpdateNama() {
        this.jtmupdatenama.getText();
    }

    public void setUpdateNama(String update) {
        this.jlupdatenama.setText(update);
    }

    public void getUpdatePass() {
        this.jtmupdatepassword.getText();
    }

    public String[] getData() {
        String data[] = new String[3]; 
        data[0] = this.jtmid.getText();
        data[1] = this.jtmupdatenama.getText();
        data[2] = this.jtmupdatepassword.getText();
        return data;
    }

    public void setUpdatepass(String update) {
        this.jlupdatepassword.setText(update);
    }

    public void setTableModel(DefaultTableModel table) {
        this.TMUser.setModel(table);
    }

    public void showMessagePane(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public int getSelectedRow() {
        return this.TMUser.getSelectedRow();
    }

    public String getIdUser() {
        return (String) this.TMUser.getValueAt(this.getSelectedRow(), 0) ;
    }

    public void setFieldIdEditable(boolean editable) {
        this.jtmid.setEditable(editable);
    }

    public void setFieldUserName(String text) {
        this.jtmupdatenama.setText(text);
    }

    public void setFieldId(String text) {
        this.jtmid.setText(text);
    }

    public void setFieldPassword(String text) {
        this.jtmupdatepassword.setText(text);
    }

    public void setUpdateEnable(boolean enable) {
        this.btnmganti.setEnabled(enable);
    }
    public void setSaveEnable(boolean enable) {
        this.btnmsave.setEnabled(enable);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jlupdatenama = new javax.swing.JLabel();
        jtmupdatenama = new javax.swing.JTextField();
        jtmupdatepassword = new javax.swing.JTextField();
        jlupdatepassword = new javax.swing.JLabel();
        btnmganti = new javax.swing.JButton();
        btnmsave = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jtmid = new javax.swing.JTextField();
        btnback = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TMUser = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jlupdatenama.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlupdatenama.setText("Nama");

        jlupdatepassword.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jlupdatepassword.setText("Password");

        btnmganti.setText("Ganti");

        btnmsave.setText("Save");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("ID");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2)
                    .addComponent(jlupdatepassword)
                    .addComponent(jtmupdatenama)
                    .addComponent(jlupdatenama)
                    .addComponent(jtmupdatepassword)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnmganti, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(btnmsave, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jtmid, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE))
                .addGap(94, 94, 94))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(jtmid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlupdatenama)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtmupdatenama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlupdatepassword)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtmupdatepassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnmganti)
                    .addComponent(btnmsave))
                .addGap(30, 30, 30))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, 330, -1));

        btnback.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnback.png"))); // NOI18N
        btnback.setBorderPainted(false);
        btnback.setContentAreaFilled(false);
        btnback.setName(""); // NOI18N
        btnback.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnbackroll.png"))); // NOI18N
        getContentPane().add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 140));
        btnback.getAccessibleContext().setAccessibleDescription("");

        TMUser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ));
        jScrollPane1.setViewportView(TMUser);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 540, 590));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ahir_BGforall.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VMKelolaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VMKelolaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VMKelolaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VMKelolaUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VMKelolaUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TMUser;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnmganti;
    private javax.swing.JButton btnmsave;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jlupdatenama;
    private javax.swing.JLabel jlupdatepassword;
    private javax.swing.JTextField jtmid;
    private javax.swing.JTextField jtmupdatenama;
    private javax.swing.JTextField jtmupdatepassword;
    // End of variables declaration//GEN-END:variables
}
