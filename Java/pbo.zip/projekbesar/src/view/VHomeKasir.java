/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.event.ActionListener;

/**
 *
 * @author USER
 */
public class VHomeKasir extends javax.swing.JFrame {

    /**
     * Creates new form vHomeKasir
     */
    public VHomeKasir() {
        initComponents();
                this.setLocationRelativeTo(this);
    }

    public void MasukModeKasir(ActionListener action) {
        this.btnktransaksi.addActionListener(action);
    }

    public void LihatStockKClick(ActionListener action) {
        this.btnkstok.addActionListener(action);
    }

    public void KelolaCustomerKClick(ActionListener action) {
        this.btnkcustomer.addActionListener(action);
    }

    public void LogoutKKClick(ActionListener action) {
        this.btnklogout.addActionListener(action);
    }

    public void setNama(String [] data) {
        this.LKId.setText(data [0]);
        this.LKnama.setText(data [1]);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnktransaksi = new javax.swing.JButton();
        btnkcustomer = new javax.swing.JButton();
        btnkstok = new javax.swing.JButton();
        btnklogout = new javax.swing.JButton();
        LKnama = new javax.swing.JLabel();
        LKId = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1300, 850));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnktransaksi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnmodekasir.png"))); // NOI18N
        btnktransaksi.setBorderPainted(false);
        btnktransaksi.setContentAreaFilled(false);
        btnktransaksi.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnmodekasirroll.png"))); // NOI18N
        getContentPane().add(btnktransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 480, -1, -1));

        btnkcustomer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnckasir.png"))); // NOI18N
        btnkcustomer.setBorderPainted(false);
        btnkcustomer.setContentAreaFilled(false);
        btnkcustomer.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnckasirroll.png"))); // NOI18N
        getContentPane().add(btnkcustomer, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 480, 380, -1));

        btnkstok.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnstok.png"))); // NOI18N
        btnkstok.setBorderPainted(false);
        btnkstok.setContentAreaFilled(false);
        btnkstok.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnstokroll.png"))); // NOI18N
        getContentPane().add(btnkstok, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 660, -1, -1));

        btnklogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnlogout.png"))); // NOI18N
        btnklogout.setBorderPainted(false);
        btnklogout.setContentAreaFilled(false);
        btnklogout.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnklogout.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnlogoutroll.png"))); // NOI18N
        getContentPane().add(btnklogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1167, 170, 110, -1));

        LKnama.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        getContentPane().add(LKnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 110, 130, 20));

        LKId.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        getContentPane().add(LKId, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 90, 70, 20));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ahir_vhomekasir.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VHomeKasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VHomeKasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VHomeKasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VHomeKasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VHomeKasir().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LKId;
    private javax.swing.JLabel LKnama;
    private javax.swing.JButton btnkcustomer;
    private javax.swing.JButton btnklogout;
    private javax.swing.JButton btnkstok;
    private javax.swing.JButton btnktransaksi;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
