/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Msupplier extends ModelParents {

    public Msupplier() throws SQLException {
    }

    @Override
    public boolean updateData(String data[]) throws SQLException {
        query = "update supplier SET Nama = '" + data[1] + "' , Alamat = '" + data[2] + "' , NoHP = '" + data[3] + "' where Supplier_ID = '" + data[0] + "'";
        return super.updateData(data);
    }

    @Override
    public boolean insertData(String data[]) throws SQLException {
        String queryID = "select Supplier_ID from supplier ";
        ResultSet rsID = con.getResult(queryID);

        rsID.last();
        String baris = rsID.getString(1);
        String kata[] = baris.split("L");
        int angka = Integer.valueOf(kata[1]);
        angka++;
        String ID = "SPL";
        ID += String.valueOf(angka);

        query = "INSERT INTO `supplier`(`Supplier_id`,`Nama`,`Alamat`,`NoHP`) VALUES ('" + ID + "','" + data[0] + "','" + data[1] + "','" + data[2] + "')";
        return super.insertData(data);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[4];
        String query = "select Supplier_ID, Nama, Alamat, NoHP from supplier where Supplier_ID = '" + ID + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1);
            }
        }
        return data;
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"ID", "Nama", "Alamat", "NoHP"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = "select Supplier_ID, Nama, Alamat, NoHP from supplier ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[4];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    public DefaultTableModel getDataKualitas() throws SQLException {
        String kolom[] = {"ID", "Nama", "QualityAverage"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = "select Supplier_ID, Nama,QualityAverage from supplier ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[3];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

}
