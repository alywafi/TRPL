package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 */
public class Mtransaksi extends ModelParents implements ModelInterface {

    public Mtransaksi() throws SQLException {

    }

    @Override
    public DefaultTableModel getDataJenisIkan() throws SQLException {
        String kolom[] = {"ID", "Nama", "MaksHargaBeli", "Stok"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = " select * from jenisikan ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[4];
            for (int i = 0; i < row.length; i++) {
                if (i == 2) {
                    row[i] = String.valueOf(Integer.valueOf(rs.getString(i + 1)) + 2000);

                } else {
                    row[i] = rs.getString(i + 1);

                }
            }
            table.addRow(row);
        }

        return table;
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[2];
        String query = "select Nama, MaksHargaBeli from jenisikan where jenisikan_id = '" + ID + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            for (int i = 0; i < data.length; i++) {
                if (i == 1) {
                    data[i] = String.valueOf(Integer.valueOf(rs.getString(i + 1)) + 2000);
                } else {
                    data[i] = rs.getString(i + 1);
                }
            }
        }
        return data;
    }

    @Override
    public boolean insertData(String data[]) throws SQLException {
        System.out.println(data[0]);
        System.out.println(data[1]);
        System.out.println(data[2]);
        System.out.println(data[3]);
        query = "INSERT INTO `transaksi`(`transaksi_id`,`karyawan_id`,`customer_id`) VALUES ('" + data[0] + "','" + data[1] + "','" + data[2] + "')";
        return super.insertData(data);
    }

    @Override
    public String GetId() throws SQLException {
        String queryID = "select transaksi_ID from transaksi ";
        ResultSet rsID = con.getResult(queryID);

        rsID.last();
        String baris = rsID.getString(1);
        String kata[] = baris.split("A");
        int angka = Integer.valueOf(kata[1]);
        angka += 1;
        String ID = "TRA";
        return ID += String.valueOf(angka);
    }

    @Override
    public String getIDWithData(String[] Data) throws SQLException {
        String id = null;
        String query = "select jenisikan_id from jenisikan where Nama = '" + Data[0] + "' and MaksHargaBeli = '" + (String.valueOf(Integer.valueOf(Data[1]) - 2000)) + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            id = rs.getString(1);
        }
        return id;
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"transaksi_ID", "customer_ID", "karyawan_ID", "Date", "jenisikan_ID", "HargaBeli", "Quantity", "Total"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = "select t.transaksi_ID , t.customer_ID, t.karyawan_ID , t.Date, dt.jenisikan_id , "
                + "dt.HargaBeli, dt.Quantity , ( dt.HargaBeli * dt.Quantity) as Total  from transaksi t join "
                + "detailtransaksi dt on t.transaksi_ID = dt.transaksi_ID ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[8];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    @Override
    public boolean insertDataToDetailed(String Id, String data[]) throws SQLException {

        int Transaksi = 0;
        int Transaksiinput = 0;

        String queryGetdata = "select Stok from jenisikan where jenisikan_id = '" + data[0] + "'";
        ResultSet rsget = con.getResult(queryGetdata);
        if (rsget.next()) {
            Transaksi = Integer.valueOf(rsget.getString(1));
        }
        Transaksiinput = Transaksi - Integer.valueOf(data[2]);

        String queryStokJenisIkan = "UPDATE jenisikan SET stok = '" + Transaksiinput + "' WHERE jenisikan_id = '" + data[0] + "'";
        try {
            con.executeQuery(queryStokJenisIkan);
        } catch (SQLException ex) {
        }

        String querytr = "INSERT INTO `detailtransaksi`(`transaksi_ID`, `jenisikan_id`, `Quantity`, `HargaBeli`) VALUES ('" + Id + "','" + data[0] + "','" + data[2] + "','" + data[1] + "')";
        boolean succesInput;
        try {
            con.executeQuery(querytr);
            succesInput = true;
        } catch (SQLException ex) {
            succesInput = false;
        }
        return succesInput;
    }
}
