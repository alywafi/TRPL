package model;

import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public interface ModelInterface {

    public String GetId() throws SQLException;

    public String getIDWithData(String[] Data) throws SQLException;

    public DefaultTableModel getDataJenisIkan() throws SQLException;

    public boolean insertDataToDetailed(String Id, String data[]) throws SQLException;

}
