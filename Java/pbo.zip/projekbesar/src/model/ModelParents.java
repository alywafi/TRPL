package model;

import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public abstract class ModelParents {

    DefaultTableModel model;
    String[] dataID;
    Koneksi con;
    String query ;

    public ModelParents() throws SQLException {
        this.con = new Koneksi();
    }

    protected DefaultTableModel getData() throws SQLException {
        return model;
    }

    protected String[] getDataWithID(String ID) throws SQLException {
        return dataID;    }

    protected boolean insertData(String[] ID) throws SQLException {
        try {
            con.executeQuery(query);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    protected boolean updateData(String[] ID) throws SQLException {
        try {
            con.executeQuery(query);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

 
}
