package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 */
public class Mstok extends ModelParents implements ModelInterface {

    Koneksi con;

    public Mstok() throws SQLException {
        con = new Koneksi();
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[2];
        String query = "select Nama, MaksHargaBeli from jenisikan where jenisikan_id = '" + ID + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1);
            }
        }
        return data;
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"JenisIkan_ID", "Nama", "Stok"};
        DefaultTableModel model = new DefaultTableModel(null, kolom);
        String query = "select JenisIkan_ID, Nama, Stok from jenisikan ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[3];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            model.addRow(row);
        }

        return model;
    }

    @Override
    public boolean insertData(String data[]) throws SQLException {
        query = "select * from stok";
//        query = "INSERT INTO `stok`(`stok_id`,`karyawan_id`,`supplier_id`) VALUES ('" + data[0] + "','" + data[1] + "','" + data[2] +  "')";
        boolean succesInput;
        return super.insertData(data);
    }

    @Override
    public boolean insertDataToDetailed(String Id, String data[]) throws SQLException {

        int stok = 0;
        int stokinput = 0;

        String queryGetdata = "select Stok from jenisikan where jenisikan_id = '" + data[0] + "'";
        ResultSet rsget = con.getResult(queryGetdata);
        if (rsget.next()) {
            stok = Integer.valueOf(rsget.getString(1));
        }
        stokinput = stok + Integer.valueOf(data[2]);

        String queryStokJenisIkan = "UPDATE jenisikan SET stok = '" + stokinput + "' WHERE jenisikan_id = '" + data[0] + "'";
        try {
            con.executeQuery(queryStokJenisIkan);
        } catch (SQLException ex) {
        }

        String query = "INSERT INTO `datailstok`(`Stok_id`, `jenisikan_ID`, `Quantity`, `HargaBeli`) VALUES ('" + Id + "','" + data[0] + "','" + data[2] + "','" + data[1] + "')";
        boolean succesInput;
        try {
            con.executeQuery(query);
            succesInput = true;
        } catch (SQLException ex) {
            succesInput = false;
        }
        return succesInput;
    }

    @Override
    public String GetId() throws SQLException {
        String queryID = "select stok_ID from stok ";
        ResultSet rsID = con.getResult(queryID);

        rsID.last();
        String baris = rsID.getString(1);
        String kata[] = baris.split("K");
        int angka = Integer.valueOf(kata[1]);
        angka++;
        String ID = "STK";
        return ID += String.valueOf(angka);
    }

    @Override
    public DefaultTableModel getDataJenisIkan() throws SQLException {
        String kolom[] = {"ID", "Nama", "MaksHargaBeli", "Stok"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = " select * from jenisikan ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[4];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    @Override
    public String getIDWithData(String[] Data) throws SQLException {
        String id = null;
        String query = "select jenisikan_id from jenisikan where Nama = '" + Data[0] + "' and MaksHargaBeli = '" + Data[1] + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            id = rs.getString(1);
        }
        return id;
    }

    public boolean insertDataToQuality(String data[]) throws SQLException {

        int kua = 0;
        int kuainput = 0;

        String queryGetdata = "select QualityAverage from supplier where supplier_id = '" + data[0] + "'";
        ResultSet rsget = con.getResult(queryGetdata);
        if (rsget.next()) {
            kua = Integer.valueOf(rsget.getString(1));
        }
        kuainput = (kua + Integer.valueOf(data[1])) / 2;

        String query = "UPDATE supplier SET QualityAverage= '" + kuainput + "' WHERE supplier_id = '" + data[0] + "'";
        boolean succesInput;
        try {
            con.executeQuery(query);
            succesInput = true;
        } catch (SQLException ex) {
            succesInput = false;
        }
        return succesInput;
    }
}
