package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class MjenisIkan extends ModelParents {

    public MjenisIkan() throws SQLException {
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"ID", "Nama", "MaksHargaBeli"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = "select jenisikan_ID, Nama, makshargabeli from jenisikan ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[3];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    @Override
    public boolean updateData(String data[]) throws SQLException {
        query = "update jenisikan SET Nama = '" + data[1] + "' , MaksHargaBeli = '" + data[2] + "' where jenisikan_ID = '" + data[0] + "'";
        return super.updateData(data);
    }

    @Override
    public boolean insertData(String data[]) throws SQLException {
        String queryID = "select jenisikan_ID from jenisikan ";
        ResultSet rsID = con.getResult(queryID);

        rsID.last();
        String baris = rsID.getString(1);
        String kata[] = baris.split("K");
        int angka = Integer.valueOf(kata[1]);
        angka++;
        String ID = "JIK";
        ID += String.valueOf(angka);
        System.out.println(ID);

        query = "INSERT INTO `jenisikan`(`jenisikan_id`,`Nama`,`MaksHargaBeli`) VALUES ('" + ID + "','" + data[0] + "','" + data[1] + "')";
        return super.insertData(data);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[3];
        System.out.println(ID);
        String query = "select jenisikan_ID, Nama, MaksHargaBeli from jenisikan where jenisikan_ID = '" + ID + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1);
            }
        }
        return data;
    }
}
