package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Mcustomer extends ModelParents {

    public Mcustomer() throws SQLException {
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"ID", "Nama", "Alamat", "NoHP"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = "select customer_ID, Nama, Alamat, NoHP from customer ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[4];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    @Override
    public boolean updateData(String data[]) throws SQLException {
        query = "update customer SET Nama = '" + data[1] + "' , Alamat = '" + data[2] + "', NoHP = '" + data[3] + "' where customer_ID = '" + data[0] + "'";
        return super.updateData(data);

    }

    @Override
    public boolean insertData(String data[]) throws SQLException {
        String queryID = "select customer_ID from customer ";
        ResultSet rsID = con.getResult(queryID);

        rsID.last();
        String baris = rsID.getString(1);
        String kata[] = baris.split("S");
        int angka = Integer.valueOf(kata[1]);
        angka++;
        String ID = "CUS";
        ID += String.valueOf(angka);

        query = "INSERT INTO `customer`(`customer_id`,`Nama`,`Alamat`,`NoHP`, `Password`) VALUES ('" + ID + "','" + data[0] + "','" + data[1] + "','" + data[2]
                + "','" + data[3] + "')";
        return super.insertData(data);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[4];
        String query = "select customer_ID, Nama, Alamat, NoHP from customer where Customer_ID = '" + ID + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1);
            }
        }
        return data;
    }

}
