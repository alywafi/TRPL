package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Mkaryawan extends ModelParents {

    public Mkaryawan() throws SQLException {
    }

    @Override
    public DefaultTableModel getData() throws SQLException {
        String kolom[] = {"ID", "Nama", "Alamat", "Jabatan", "NoHP"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = "select Karyawan_ID, Nama, Alamat, Jabatan, NoHP from karyawan ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[5];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    @Override
    public boolean updateData(String data[]) throws SQLException {
        query = "update karyawan SET Nama = '" + data[1] + "' , Alamat = '" + data[2] + "' , Jabatan = '" + data[3] + "' , "
                + "NoHP = '" + data[4] + "' where Karyawan_ID = '" + data[0] + "'";
        return super.updateData(data);
    }

    @Override
    public boolean insertData(String data[]) throws SQLException {
        String Jabatan;

        if (data[2] == "Manager") {
            Jabatan = "MNG";
        } else if (data[2] == "Kasir") {
            Jabatan = "KSR";
        } else {
            Jabatan = "GDG";
        }
        String queryID = "select Karyawan_ID from karyawan where Karyawan_ID like '" + Jabatan + "%'";
        ResultSet rsID = con.getResult(queryID);

        rsID.last();
        String baris = rsID.getString(1);
        String initialAngka = "";
        for (int i = 4; i <= baris.length(); i++) {
            initialAngka += String.valueOf(baris.charAt(i - 1));
        }
        int angka = Integer.valueOf(initialAngka);
        angka++;

        String ID = Jabatan;
        ID += String.valueOf(angka);
        query = "INSERT INTO `karyawan`(`Karyawan_ID`, `Nama`, `Alamat`, `Jabatan`, `NoHP`, `Password`) VALUES ('" + ID + "','" + data[0] + "','" + data[1]
                + "','" + data[2] + "','" + data[3] + "','" + data[4] + "')";
        return super.insertData(data);
    }

    @Override
    public String[] getDataWithID(String ID) throws SQLException {
        String data[] = new String[5];
        String query = "select Karyawan_ID, Nama, Alamat, Jabatan, NoHP from karyawan where Karyawan_ID = '" + ID + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1);
            }
        }
        return data;
    }

    public String GetID(String Nama, String pass) throws SQLException {
        String ID = null;
        String query = "select karyawan_id from karyawan where nama = '" + Nama + "' and password = '" + pass + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            ID = rs.getString(1);
        }
        return ID;
    }

    public String[][] cekAkun(String[] data) throws SQLException {

        String query = "select nama,password,jabatan from karyawan";
        ResultSet rs = con.getResult(query);

        rs.last();
        int baris = rs.getRow();
        String login[][] = new String[baris][3];

        String row[] = new String[3];

        int initial = 0;
        rs.beforeFirst();
        while (rs.next()) {
            for (int i = 0; i < row.length; i++) {
                login[initial][i] = rs.getString(i + 1);
            }
            initial++;
        }
        return login;
    }

    public DefaultTableModel getDataUser() throws SQLException {
        String kolom[] = {"ID", "Nama", "Password"};
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        String query = "select Karyawan_ID, Nama, Password from karyawan ";
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[3];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1);
            }
            table.addRow(row);
        }

        return table;
    }

    public boolean updateDataUser(String data[]) {
        String query = "update karyawan SET Nama = '" + data[1] + "' , Password = '" + data[2] + "' where Karyawan_ID = '" + data[0] + "'";
        boolean UpdateStatus;
        try {
            con.executeQuery(query);
            UpdateStatus = true;
        } catch (SQLException ex) {
            UpdateStatus = false;
        }
        return UpdateStatus;
    }

    public String[] getDataUserWithID(String ID) throws SQLException {
        System.out.println(ID);
        String data[] = new String[3];
        String query = "select Karyawan_ID, Nama, Password from karyawan where Karyawan_ID = '" + ID + "'";
        ResultSet rs = con.getResult(query);
        if (rs.next()) {
            for (int i = 0; i < data.length; i++) {
                data[i] = rs.getString(i + 1);
            }
        }
        return data;
    }

}
