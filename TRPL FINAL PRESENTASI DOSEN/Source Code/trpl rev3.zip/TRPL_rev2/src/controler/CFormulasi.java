package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import view.viewFormulasi;
import view.viewHasilFormulasi;

public class CFormulasi {

    viewFormulasi view1;
    viewHasilFormulasi viewhasil;

    public CFormulasi() {
        this.view1 = new viewFormulasi();
        this.viewhasil = new viewHasilFormulasi();
        view1.setVisible(true);

        view1.getHitung().addActionListener(new HitungAction());

    }

    private class HitungAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String[] dataBasal = view1.getDataBasalterpilih();
            String[] dataSupp = view1.getDataSuplementterpilih();
            double basal;
            double supp;
            double basalsupp;
            double kebutuhanBasal;
            double kebutuhanSupp;
            double perbahanbasal;
            double perbahanSupp;
            String [] kolom = {"Bahan Baku", "Kuantitas"};
            DefaultTableModel a = new DefaultTableModel(null,kolom);
            basal = view1.getDataSuplement() - view1.getProtein();
            supp = view1.getProtein() - view1.getDataBasal();
            basalsupp = basal + supp;
            kebutuhanBasal = basal / basalsupp * (view1.getBobot() * 0.9);
            kebutuhanSupp = supp / basalsupp * (view1.getBobot() * 0.9);

            perbahanbasal = kebutuhanBasal / dataBasal.length;
            perbahanSupp = kebutuhanSupp / dataSupp.length;

            for (int i = 0; i < dataBasal.length; i++) {
                String[] row = new String[2];
                row[0] = dataBasal[i];
                row[1] = String.valueOf(perbahanbasal) ;
                a.addRow(row);
            }
            
            for (int i = 0; i < dataSupp.length; i++) {
                String[] row = new String[2];
                row[0] = dataSupp[i];
                row[1] = String.valueOf(perbahanSupp) ;
                a.addRow(row);
            }
            viewhasil.setmodel(a);
            viewhasil.setVisible(true);
            view1.dispose();
            

        }
    }

}
