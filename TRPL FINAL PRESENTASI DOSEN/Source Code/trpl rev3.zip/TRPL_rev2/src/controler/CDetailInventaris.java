package controler;

/*
wkwkwkwk
 */
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import model.MInventaris;
import view.popup_detailinvntaris;
import view.viewDetailInventaris;
import view.viewHomeAdmin;

/**
 *
 * @author acer
 */
public class CDetailInventaris {

    viewDetailInventaris view;
    MInventaris model;
    popup_detailinvntaris popup;
    String username;

    public CDetailInventaris(viewDetailInventaris view, MInventaris model, popup_detailinvntaris popup, String Username) throws SQLException {
        this.view = view;
        this.model = model;
        this.popup = popup;
        this.username = Username;
        view.setVisible(true);
        view.klikexit(new exitaction());
        view.klikminimize(new minimizeaction());
        view.klikubah(new ubahAction());
        view.kliktambah(new tambahAction());
        view.setTableModel(model.getDatainventaris());
        view.SetName(Username);
        popup.simpan(new kliksimpan());
        view.KlikBack(new BackAction());
        view.setVisible(true);
    }

    private class tambahAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            popup.IdEditable();
            popup.setButtonText("save");
            popup.setVisible(true);
            popup.setStokText("Stok");
        }
    }

    private class ubahAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            popup.IdEditable();
            popup.setButtonText("update");
            popup.setdata(view.getDataOnTable());;
            popup.setVisible(true);
            popup.setStokText("Penambahan/Pengurangan Stok");
        }
    }

    private class BackAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            controler.CHomeAdmin e = new controler.CHomeAdmin(new view.viewHomeAdmin(), username);
            view.dispose();
        }
    }

    private class kliksimpan implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (popup.getButtonText().equals("save")) {
                String data[] = popup.getdata();
                if (Integer.parseInt(data[2])>Integer.parseInt(data[3])) {

                    if (model.insertDataInventaris(data)) {
                        view.message("insert data Inventaris berhasil");
                    } else {
                        view.message("insert data Inventaris gagal cek kembali inputan anda");
                    }
                    try {
                        view.setTableModel(model.getDatainventaris());
                    } catch (SQLException ex) {
                        Logger.getLogger(CDetailInventaris.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else{
                view.message("data stock yang anda inputkan salah");
                }
                popup.dispose();
            } else {
                try {
                    if (model.updateDataInventaris(popup.getdata())) {
                        view.message("update data Inventaris berhasil");
                    } else {
                        view.message("update data Inventaris gagal cek kembali inputan anda");
                    }
                    view.setTableModel(model.getDatainventaris());
                    popup.dispose();
                } catch (SQLException ex) {
                    Logger.getLogger(CDetailInventaris.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    private class exitaction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    private class minimizeaction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            view.setState(Frame.ICONIFIED);
        }
    }
}
